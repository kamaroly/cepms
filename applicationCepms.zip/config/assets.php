<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['assets_url'] = '/assets/';

/* End of file assets.php */
/* Location: ./application/config/assets.php */