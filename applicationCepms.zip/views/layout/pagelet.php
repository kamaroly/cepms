<?php if($this->uri->segment(1)!='auth' && $this->uri->segment(2)!='login'):?>
<?php echo $header; ?>
<?php endif;?>


            <?php echo $main_content; ?>
     

<?php  //echo $footer; ?>