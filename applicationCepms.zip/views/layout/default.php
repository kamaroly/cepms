<?php echo $main_content; ?>
