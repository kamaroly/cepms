<?php 
class Contributions_refund_model extends MY_Model{

     public $_table='contributions_refund';
     public $primary_key = 'memberid';


}