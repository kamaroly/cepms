<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User_model extends MY_Model{ 

	public $_table ='users';
	public $primary_key = 'id';
}

