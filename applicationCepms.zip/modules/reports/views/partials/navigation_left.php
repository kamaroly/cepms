 <section class="sidebar">
                  
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li>
                           <a data-toggle="modal" href="<?php echo site_url('reports/datefilter/contributions') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Contribution report</strong>
                </a>
                        </li>
                        <li>
                           
 <a data-toggle="modal" href="<?php echo site_url('reports/datefilter/membersloans') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Member loans report</strong>
                </a>
                        </li>
                       
                    </ul>
</section>