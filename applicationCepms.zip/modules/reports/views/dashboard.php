
<div class="container">
<div class="main-inner ">

    <div class="span6">
      
<div class="widget">
              
              <div class="widget-header">
                <a data-toggle="modal" href="http://cepms/loans/payment/1" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <h3>Members report </h3>
                </a>

            </div> <!-- /widget-header -->
          
 <div class="widget-content">
 Below are member related reports.
<br>
<p>
 <a target="_blank"  href="<?php echo site_url('reports/activestatus/active') ?>"  >
                  <i class="icon-th-list"></i>
                  <strong>Active members</strong>
                </a>
&nbsp;&nbsp;
 <a target="_blank" href="<?php echo site_url('reports/activestatus/inactive') ?>" >
                  <i class="icon-th-list"></i>
                  <strong>Inactive Members</strong>
                </a>
 </p>
 <p>
 <a target="_blank" href="<?php echo site_url('reports/activestatus/all') ?>" >
                  <i class="icon-th-list"></i>
                  <strong>All members</strong>
                </a>

 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<a data-toggle="modal" href="<?php echo site_url('reports/memberfilter/activestatus') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Member Records</strong>
                </a>
</p>

 <a data-toggle="modal" href="<?php echo site_url('reports/memberfilter/activeloanhistory') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Laon History</strong>
                </a>


 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

 <a data-toggle="modal" href="<?php echo site_url('reports/memberfilter/paybackplan') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>PayBack Plan</strong>
                </a>
 </p>
      </div>
    </div>
  </div>
  </div>

    <div class=" span6 container">
      
<div class="widget ">
              
              <div class="widget-header">
                <a data-toggle="modal" href="http://cepms/loans/payment/1" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <h3>Contributions report </h3>
                </a>

            </div> <!-- /widget-header -->
          
 <div class="widget-content">
Below are the available contribution reports
<br>
<p>
 <a data-toggle="modal" href="<?php echo site_url('reports/datefilter/contributions') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Contribution report</strong>
                </a>
 </p>

 <p>
 <a data-toggle="modal" href="<?php echo site_url('reports/memberfilter/contributions') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Individual contribution</strong>
                </a>
 </p>



  <p>
 <a target="_blank"  href="<?php echo site_url('reports/returnedcontribution') ?>" >
                  <i class="icon-th-list"></i>
                  <strong>Returned  Contribution</strong>
                </a>
 </p>
      </div>
    </div>
    </div>

    
    </div>
  
  


<div class="container">
<div class="main-inner  ">
    <div class=" span6">
      
<div class="widget  ">
              
              <div class="widget-header">
                <a data-toggle="modal" href="http://cepms/loans/payment/1" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <h3>Loans report </h3>
                </a>

            </div> <!-- /widget-header -->
          
 <div class="widget-content">
These are loan related reports
<br>
<p>
 <a data-toggle="modal" href="<?php echo site_url('reports/datefilter/membersgivenloans') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Given Loans</strong>
                </a>
 </p>

<p>
 <a data-toggle="modal" href="<?php echo site_url('reports/datefilter/loansPayedAmount') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Paid Loans</strong>
                </a>
 </p>

 <p>
 <a data-toggle="modal" href="<?php echo site_url('reports/datefilter/delayedloan') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Delayed Loans</strong>
                </a>
 </p>
 <p>
 <a data-toggle="modal" href="<?php echo site_url('reports/datefilter/loansnotyetpaid') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>loans not yet paid</strong>
                </a>
 </p>
  <a data-toggle="modal" href="<?php echo site_url('reports/datefilter/transferedLoan') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>TRANSFERED LOAN</strong>
                </a>
 </p>
  <p>
 <a data-toggle="modal" href="<?php echo site_url('reports/memberfilter/membersloans') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Member loans report</strong>
                </a>
 </p>
 
      </div>
    </div>
  </div>
  </div>

    <div class=" span6 container">
      
<div class="widget ">
              
              <div class="widget-header">
                <a data-toggle="modal" href="http://cepms/loans/payment/1" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <h3>Bank  and  Production  report </h3>
                </a>

            </div> <!-- /widget-header -->
          
 <div class="widget-content">
These are bank accounts related reports
<br>
<p>
 <a data-toggle="modal" href="<?php echo site_url('reports/accountfilter/AccountActivies') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Account  Activity</strong>
                </a>
 </p>

 <p>
 <a data-toggle="modal"  href="<?php echo site_url('reports/accountfilter2/AccountProduction') ?>" data-target="#utility" >
                  <i class="icon-th-list"></i>
                  <strong>Production Report</strong>
                </a>
 </p>
 <p>
 <a data-toggle="modal"  data-target="#utility" href="<?php echo site_url('reports/accountfilter3/Gift') ?>">
                  <i class="icon-th-list"></i>
                  <strong>Gift Report</strong>
                </a>
 </p>

 <p>
 <a data-toggle="modal"  data-target="#utility" href="<?php echo site_url('reports/accountfilter/bilan') ?>" >
                  <i class="icon-th-list"></i>
                  <strong>Bilan</strong>
                </a>
 </p>


      </div>
    </div>
    </div>

    
    </div>
  
  

