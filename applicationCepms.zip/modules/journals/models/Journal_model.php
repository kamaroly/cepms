<?php 

class Journal_model extends MY_Model{

     public $_table='journals';
     public $primary_key = 'id';
	 //Get all journals in the db
     

    
}
