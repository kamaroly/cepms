<legend>Contribution per level</legend>
<fieldset>
  <div class="row">
    <!-- A0-->
                <div class="control-group span4">                     
                      <label class="control-label"><strong>A0 CEP :</strong></label>
                      <div class="controls">
                        <input type="text" name="A0_cep" value="<?php echo $this->config->item('A0_cep'); ?>">
                      </div>
                </div>
                <div class="control-group span4">                     
                      <label class="control-label"><strong>A0 Social :</strong></label>
                      <div class="controls">
                        <input type="text" name="A0_social" value="<?php echo $this->config->item('A0_social'); ?>" >
                      </div>
                </div>
              
               <div class="control-group span4">                     
                      <label class="control-label"><strong>A0 Top Up :</strong></label>
                      <div class="controls">
                        <input type="text" name="A0_topup" value="<?php echo $this->config->item('A0_topup'); ?>" >
                      </div>
                </div>
    <!-- end of A0-->

    <!-- start of A1-->
                <div class="control-group span4">                     
                      <label class="control-label"><strong>A1 CEP :</strong></label>
                      <div class="controls">
                        <input type="text" name="A1_cep" value="<?php echo $this->config->item('A1_cep'); ?>">
                      </div>
                </div>
                <div class="control-group span4">                     
                      <label class="control-label"><strong>A1 Social :</strong></label>
                      <div class="controls">  
                        <input type="text" name="A1_social" value="<?php echo $this->config->item('A1_social'); ?>" >
                      </div>
                </div>

                <div class="control-group span4">                     
                      <label class="control-label"><strong>A1 Top Up :</strong></label>
                      <div class="controls">  
                        <input type="text" name="A1_topup" value="<?php echo $this->config->item('A1_topup'); ?>" >
                      </div>
                </div>
   <!-- end of A1-->

   <!-- start of A2--> 
                  <div class="control-group span4">                     
                      <label class="control-label"><strong>A2 CEP :</strong></label>
                      <div class="controls">
                        <input type="text" name="A2_cep" value="<?php echo $this->config->item('A2_cep'); ?>">
                      </div>
                </div>
                <div class="control-group span4">                     
                      <label class="control-label"><strong>A2 Social :</strong></label>
                      <div class="controls">
                        <input type="text" name="A2_social" value="<?php echo $this->config->item('A2_social'); ?>" >
                      </div>
                </div>
                <div class="control-group span4">                     
                      <label class="control-label"><strong>A2 Top Up :</strong></label>
                      <div class="controls">
                        <input type="text" name="A2_topup" value="<?php echo $this->config->item('A2_topup'); ?>" >
                      </div>
                </div>
   <!-- end of A2--> 
      <!-- start of A3--> 
               <div class="control-group span4">                     
                      <label class="control-label"><strong>A3 CEP :</strong></label>
                      <div class="controls">
                        <input type="text" name="A3_cep" value="<?php echo $this->config->item('A3_cep'); ?>">
                      </div>
                </div>
                <div class="control-group span4">                     
                      <label class="control-label"><strong>A3 Social :</strong></label>
                      <div class="controls">
                        <input type="text" name="A3_social" value="<?php echo $this->config->item('A3_social'); ?>" >
                      </div>
                </div>
               <div class="control-group span4">                     
                      <label class="control-label"><strong>A3 Top Up :</strong></label>
                      <div class="controls">
                        <input type="text" name="A3_topup" value="<?php echo $this->config->item('A3_topup'); ?>" >
                      </div>
                </div>
     <!-- end of A3--> 

         <!-- start of Dr Generaliste--> 
                 <div class="control-group span4">                     
                      <label class="control-label"><strong>Dr Generaliste CEP :</strong></label>
                      <div class="controls">
                        <input type="text" name="Dr_Generaliste_cep" value="<?php echo $this->config->item('Dr_Generaliste_cep'); ?>">
                      </div>
                </div>
                <div class="control-group span4">                     
                      <label class="control-label"><strong>Dr Generaliste Social :</strong></label>
                      <div class="controls">
                        <input type="text" name="Dr_Generaliste_social" value="<?php echo $this->config->item('Dr_Generaliste_social'); ?>" >
                      </div>
                </div>
                <div class="control-group span4">                     
                      <label class="control-label"><strong>Dr Generaliste Top UP :</strong></label>
                      <div class="controls">
                        <input type="text" name="Dr_Generaliste_topup" value="<?php echo $this->config->item('Dr_Generaliste_topup'); ?>" >
                      </div>
                </div>
        <!-- end of Dr Generaliste-->  

  <!-- start of MASTER--> 
                <div class="control-group span4">                     
                      <label class="control-label"><strong>MASTER CEP :</strong></label>
                      <div class="controls">
                        <input type="text" name="MASTER_cep" value="<?php echo $this->config->item('MASTER_cep'); ?>">
                      </div>
                </div>

                <div class="control-group span4">                     
                      <label class="control-label"><strong>MASTER Social :</strong></label>
                      <div class="controls">
                        <input type="text" name="MASTER_social" value="<?php echo $this->config->item('MASTER_social'); ?>">
                      </div>
                </div>
                <div class="control-group span4">                     
                      <label class="control-label"><strong>MASTER Top UP :</strong></label>
                      <div class="controls">
                        <input type="text" name="MASTER_topup" value="<?php echo $this->config->item('MASTER_topup'); ?>">
                      </div>
                </div>
            <!-- end of MASTER-->  

                 <div class="control-group span4">                     
                      <label class="control-label"><strong>SPECIALISTE CEP :</strong></label>
                      <div class="controls">
                        <input type="text" name="SPECIALISTE_cep" value="<?php echo $this->config->item('SPECIALISTE_cep'); ?>" >
                      </div>
                </div>
                <div class="control-group span4">                     
                      <label class="control-label"><strong>SPECIALISTE Social :</strong></label>
                      <div class="controls">
                        <input type="text" name="SPECIALISTE_social" value="<?php echo $this->config->item('SPECIALISTE_social'); ?>" >
                      </div>
                </div>
            <div class="control-group span4">                     
                      <label class="control-label"><strong>SPECIALISTE Top Up :</strong></label>
                      <div class="controls">
                        <input type="text" name="SPECIALISTE_topup" value="<?php echo $this->config->item('SPECIALISTE_topup'); ?>" >
                      </div>
                </div>
    </div>
  </fieldset>




